require('./system.js');System.register("Common/app/Common/Color", [], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Color;
    return {
        setters:[],
        execute: function() {
            /*[Serializable]*/
            Color = (function () {
                function Color(r, g, b, a) {
                    if (a === void 0) { a = 1; }
                    this.R = r;
                    this.G = g;
                    this.B = b;
                    this.A = a;
                }
                return Color;
            }());
            exports_1("Color", Color);
        }
    }
});
System.register("Lambdas/getGameState", ["Common/app/Common/Color"], function(exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var Color_1;
    var aws, s3, m, handler;
    return {
        setters:[
            function (Color_1_1) {
                Color_1 = Color_1_1;
            }],
        execute: function() {
            aws = require('aws-sdk');
            s3 = new aws.S3({});
            m = new Color_1.Color(1, 1, 1);
            exports_2("handler", handler = function (event, context) {
                var key = "Angel Island Zone Act 1.min.js";
                console.log('Received event:', event);
                console.log('Received event:', context);
                // Get the object from the event and show its content type
                var params = {
                    Bucket: 'sonic-levels',
                    Key: key
                };
                s3.getObject(params, function (err, data) {
                    context.succeed(data.Body.toString('ascii'));
                });
            });
        }
    }
});
System.register("Lambdas/main", ["Lambdas/getGameState"], function(exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var f;
    function handler(event, context) { f.handler(event, context); }
    exports_3("handler", handler);
    return {
        setters:[
            function (f_1) {
                f = f_1;
            }],
        execute: function() {
        }
    }
});
exports.handler = function (event, context) {console.log("getGameState");System.import("Lambdas/main").then(function (module) {console.log("3");module.handler(event, context);console.log("4");});}