global.aws = require('aws-sdk');require('./system.js');require('./RawDeflate.js');var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
System.register("Common/Color", [], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Color;
    return {
        setters:[],
        execute: function() {
            /*[Serializable]*/
            Color = (function () {
                function Color(r, g, b, a) {
                    if (a === void 0) { a = 1; }
                    this.R = r;
                    this.G = g;
                    this.B = b;
                    this.A = a;
                }
                return Color;
            }());
            exports_1("Color", Color);
        }
    }
});
System.register("Common/Utils", [], function(exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var Point, DoublePoint, IntersectingRectangle, Rectangle;
    return {
        setters:[],
        execute: function() {
            Point = (function () {
                function Point(x, y) {
                    this.x = x;
                    this.y = y;
                }
                Object.defineProperty(Point.prototype, "x", {
                    get: function () {
                        return this._x | 0;
                    },
                    set: function (val) {
                        this._x = val | 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Point.prototype, "y", {
                    get: function () {
                        return this._y | 0;
                    },
                    set: function (val) {
                        this._y = val | 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                Point.Create = function (pos) {
                    return new Point(pos.x, pos.y);
                };
                Point.prototype.Offset = function (windowLocation) {
                    return new Point(this.x + windowLocation.x, this.y + windowLocation.y);
                };
                Point.prototype.NegatePoint = function (windowLocation) {
                    return new Point(this.x - windowLocation.x, this.y - windowLocation.y);
                };
                Point.prototype.Negate = function (x, y) {
                    return new Point(this.x - (x | 0), this.y - (y | 0));
                };
                Point.prototype.Set = function (x, y) {
                    this.x = x;
                    this.y = y;
                };
                return Point;
            }());
            exports_2("Point", Point);
            DoublePoint = (function () {
                function DoublePoint(x, y) {
                    this.x = x;
                    this.y = y;
                }
                DoublePoint.create = function (pos) {
                    return new DoublePoint(pos.x, pos.y);
                };
                DoublePoint.prototype.Offset = function (windowLocation) {
                    return new DoublePoint(this.x + windowLocation.x, this.y + windowLocation.y);
                };
                DoublePoint.prototype.NegatePoint = function (windowLocation) {
                    return new DoublePoint(this.x - windowLocation.x, this.y - windowLocation.y);
                };
                DoublePoint.prototype.Negate = function (x, y) {
                    return new DoublePoint(this.x - (x | 0), this.y - (y | 0));
                };
                DoublePoint.prototype.et = function (x, y) {
                    this.x = x;
                    this.y = y;
                };
                return DoublePoint;
            }());
            exports_2("DoublePoint", DoublePoint);
            IntersectingRectangle = (function (_super) {
                __extends(IntersectingRectangle, _super);
                function IntersectingRectangle(x, y, width, height) {
                    _super.call(this, x, y);
                    this.Width = width;
                    this.Height = height;
                }
                IntersectingRectangle.prototype.Intersects = function (p) {
                    return this.x < p.x && this.x + this.Width > p.x && this.y < p.y && this.y + this.Height > p.y;
                };
                IntersectingRectangle.IntersectsRect = function (r, p) {
                    return r.x < p.x && r.x + r.Width > p.x && r.y < p.y && r.y + r.Height > p.y;
                };
                IntersectingRectangle.IntersectRect = function (r1, r2) {
                    return !(r2.x > r1.x + r1.Width || r2.x + 0 < r1.x || r2.y > r1.y + r1.Height || r2.y + 0 < r1.y);
                };
                return IntersectingRectangle;
            }(Point));
            exports_2("IntersectingRectangle", IntersectingRectangle);
            Rectangle = (function (_super) {
                __extends(Rectangle, _super);
                function Rectangle(x, y, width, height) {
                    if (x === void 0) { x = 0; }
                    if (y === void 0) { y = 0; }
                    if (width === void 0) { width = 0; }
                    if (height === void 0) { height = 0; }
                    _super.call(this, x, y);
                    this.Width = width;
                    this.Height = height;
                }
                return Rectangle;
            }(Point));
            exports_2("Rectangle", Rectangle);
        }
    }
});
System.register("Common/hexLibraries/GridHexagonConstants", ["Common/Utils"], function(exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var Utils_1;
    var GridHexagonConstants;
    return {
        setters:[
            function (Utils_1_1) {
                Utils_1 = Utils_1_1;
            }],
        execute: function() {
            GridHexagonConstants = (function () {
                function GridHexagonConstants() {
                }
                GridHexagonConstants.height = function () {
                    return Math.sqrt(3) / 2 * GridHexagonConstants.width * GridHexagonConstants.heightSkew;
                };
                GridHexagonConstants.depthHeight = function () {
                    return GridHexagonConstants.height() * GridHexagonConstants.depthHeightSkew;
                };
                ;
                GridHexagonConstants.hexagonTopPolygon = function () {
                    return [new Utils_1.Point(-GridHexagonConstants.width / 2, 0), new Utils_1.Point(-GridHexagonConstants.width / 4, -GridHexagonConstants.height() / 2), new Utils_1.Point(GridHexagonConstants.width / 4, -GridHexagonConstants.height() / 2), new Utils_1.Point(GridHexagonConstants.width / 2, 0), new Utils_1.Point(GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2), new Utils_1.Point(-GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2), new Utils_1.Point(-GridHexagonConstants.width / 2, 0)];
                };
                ;
                GridHexagonConstants.hexagonDepthLeftPolygon = function (depthHeight) {
                    return [new Utils_1.Point(-GridHexagonConstants.width / 2, 0), new Utils_1.Point(-GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2), new Utils_1.Point(-GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2 + depthHeight), new Utils_1.Point(-GridHexagonConstants.width / 2, depthHeight), new Utils_1.Point(-GridHexagonConstants.width / 2, 0)];
                };
                ;
                GridHexagonConstants.hexagonDepthBottomPolygon = function (depthHeight) {
                    return [new Utils_1.Point(-GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2),
                        new Utils_1.Point(GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2),
                        new Utils_1.Point(GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2 + depthHeight),
                        new Utils_1.Point(-GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2 + depthHeight),
                        new Utils_1.Point(-GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2)];
                };
                ;
                GridHexagonConstants.hexagonDepthRightPolygon = function (depthHeight) {
                    return [new Utils_1.Point(GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2), new Utils_1.Point(GridHexagonConstants.width / 2, 0), new Utils_1.Point(GridHexagonConstants.width / 2, depthHeight), new Utils_1.Point(GridHexagonConstants.width / 4, depthHeight + GridHexagonConstants.height() / 2), new Utils_1.Point(GridHexagonConstants.width / 4, GridHexagonConstants.height() / 2)];
                };
                ;
                GridHexagonConstants.width = 100;
                GridHexagonConstants.heightSkew = .7;
                GridHexagonConstants.depthHeightSkew = .3;
                return GridHexagonConstants;
            }());
            exports_3("GridHexagonConstants", GridHexagonConstants);
        }
    }
});
///<reference path="../Common/typings/Compress.d.ts"/>
System.register("Lambdas/getGameState", ["Common/Color"], function(exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    var Color_1;
    var s3, m, handler, GameBoard, GameStateData, HexBoard, GameFaction, GameUnit;
    function random(bottom, top) {
        return (Math.random() * (top - bottom) + bottom) | 0;
    }
    return {
        setters:[
            function (Color_1_1) {
                Color_1 = Color_1_1;
            }],
        execute: function() {
            s3 = new global.aws.S3({});
            m = new Color_1.Color(1, 1, 1);
            exports_4("handler", handler = function (event, context) {
                var gameBoard = new GameBoard();
                var gameState = gameBoard.initializeGameState();
                var m = new Compressor().CompressText(JSON.stringify(gameState));
                context.succeed(m);
            });
            GameBoard = (function () {
                function GameBoard() {
                }
                GameBoard.prototype.initializeGameState = function () {
                    var stateData = new GameStateData();
                    stateData.board = new HexBoard();
                    var boardStr = "";
                    stateData.board.width = 84;
                    stateData.board.height = 84;
                    for (var y = 0; y < stateData.board.height; y++) {
                        for (var x = 0; x < stateData.board.width; x++) {
                            if (random(0, 100) < 10) {
                                boardStr += "0";
                            }
                            else {
                                if (random(0, 100) < 15)
                                    boardStr += 2;
                                else if (random(0, 100) < 6)
                                    boardStr += 3;
                                else
                                    boardStr += 1;
                            }
                            boardStr += ((y / ((stateData.board.height / 3) | 0)) | 0) + 1;
                        }
                        boardStr += "|";
                    }
                    stateData.board.boardStr = boardStr;
                    stateData.lastGeneration = new Date();
                    stateData.factions = [];
                    for (var f = 0; f < 3; f++) {
                        var gameFaction = new GameFaction();
                        gameFaction.units = [];
                        gameFaction.id = GameBoard.makeId();
                        switch (f) {
                            case 0:
                                gameFaction.color = "#FF87B7";
                                break;
                            case 1:
                                gameFaction.color = "#C4E283";
                                break;
                            case 2:
                                gameFaction.color = "#9985E5";
                                break;
                        }
                        var numOfUnits = 300;
                        var _loop_1 = function() {
                            unitType = random(0, 100);
                            var x_1 = 0;
                            var y_1 = 0;
                            while (true) {
                                x_1 = random(0, stateData.board.width);
                                y_1 = random(stateData.board.height / 3 * f, stateData.board.height / 3 * (f + 1));
                                if (gameFaction.units.filter(function (a) { return a.x === x_1 && a.y === y_1; }).length === 0) {
                                    break;
                                }
                            }
                            if (unitType < 60) {
                                gameUnit = new GameUnit();
                                gameUnit.id = GameBoard.makeId();
                                gameUnit.health = 2;
                                gameUnit.unitType = "Infantry";
                                gameUnit.x = x_1;
                                gameUnit.y = y_1;
                            }
                            else if (unitType < 90) {
                                gameUnit = new GameUnit();
                                gameUnit.id = GameBoard.makeId();
                                gameUnit.health = 6;
                                gameUnit.unitType = "Tank";
                                gameUnit.x = x_1;
                                gameUnit.y = y_1;
                            }
                            else {
                                gameUnit = new GameUnit();
                                gameUnit.id = GameBoard.makeId();
                                gameUnit.health = 16;
                                gameUnit.unitType = "Base";
                                gameUnit.x = x_1;
                                gameUnit.y = y_1;
                            }
                            gameFaction.units.push(gameUnit);
                        };
                        var unitType, gameUnit;
                        for (var i = 0; i < numOfUnits; i++) {
                            _loop_1();
                        }
                        stateData.factions.push(gameFaction);
                    }
                    return stateData;
                };
                GameBoard.makeId = function () {
                    function gen(count) {
                        var out = "";
                        for (var i = 0; i < count; i++) {
                            out += (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
                        }
                        return out;
                    }
                    return [gen(2), gen(1), gen(1), gen(1), gen(3)].join("-");
                };
                GameBoard.getUnitById = function (stateData, id) {
                    for (var _i = 0, _a = stateData.factions; _i < _a.length; _i++) {
                        var gameFaction = _a[_i];
                        for (var _b = 0, _c = gameFaction.units; _b < _c.length; _b++) {
                            var gameUnit = _c[_b];
                            if (gameUnit.id === id) {
                                return gameUnit;
                            }
                        }
                    }
                    return null;
                };
                GameBoard.getFactionByUnitId = function (stateData, unitId) {
                    for (var _i = 0, _a = stateData.factions; _i < _a.length; _i++) {
                        var gameFaction = _a[_i];
                        for (var _b = 0, _c = gameFaction.units; _b < _c.length; _b++) {
                            var gameUnit = _c[_b];
                            if (gameUnit.id === unitId) {
                                return gameFaction;
                            }
                        }
                    }
                    return null;
                };
                GameBoard.getUnitByLocation = function (stateData, x, y) {
                    for (var _i = 0, _a = stateData.factions; _i < _a.length; _i++) {
                        var gameFaction = _a[_i];
                        for (var _b = 0, _c = gameFaction.units; _b < _c.length; _b++) {
                            var gameUnit = _c[_b];
                            if (gameUnit.x === x && gameUnit.y === y) {
                                return gameUnit;
                            }
                        }
                    }
                    return null;
                };
                return GameBoard;
            }());
            exports_4("GameBoard", GameBoard);
            GameStateData = (function () {
                function GameStateData() {
                }
                return GameStateData;
            }());
            exports_4("GameStateData", GameStateData);
            HexBoard = (function () {
                function HexBoard() {
                }
                return HexBoard;
            }());
            exports_4("HexBoard", HexBoard);
            GameFaction = (function () {
                function GameFaction() {
                }
                return GameFaction;
            }());
            exports_4("GameFaction", GameFaction);
            GameUnit = (function () {
                function GameUnit() {
                }
                GameUnit.prototype.hurt = function (amount, gameState) {
                    this.health -= amount;
                    if (this.health <= 0) {
                        var faction = GameBoard.getFactionByUnitId(gameState, this.id);
                        faction.units.splice(faction.units.indexOf(this), 1);
                    }
                };
                return GameUnit;
            }());
            exports_4("GameUnit", GameUnit);
        }
    }
});
System.register("Lambdas/main", ["Lambdas/getGameState"], function(exports_5, context_5) {
    "use strict";
    var __moduleName = context_5 && context_5.id;
    var f;
    function handler(event, context) { console.log(JSON.stringify(f.handler)); f.handler(event, context); }
    exports_5("handler", handler);
    return {
        setters:[
            function (f_1) {
                f = f_1;
            }],
        execute: function() {
        }
    }
});
exports.handler = function (event, context) {console.log("getGameState");System.import("Lambdas/main").then(function (module) {console.log("3");module.handler(event, context);console.log("4");}).catch(ee=>{console.error(ee);});}