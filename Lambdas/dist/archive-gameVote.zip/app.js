global.aws = require('aws-sdk');require('./system.js');require('./RawDeflate.js');System.register("Common/Color", [], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Color;
    return {
        setters:[],
        execute: function() {
            /*[Serializable]*/
            Color = (function () {
                function Color(r, g, b, a) {
                    if (a === void 0) { a = 1; }
                    this.R = r;
                    this.G = g;
                    this.B = b;
                    this.A = a;
                }
                return Color;
            }());
            exports_1("Color", Color);
        }
    }
});
System.register("Lambdas/gameVote", ["Common/Color"], function(exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var Color_1;
    var m, handler;
    return {
        setters:[
            function (Color_1_1) {
                Color_1 = Color_1_1;
            }],
        execute: function() {
            m = new Color_1.Color(1, 1, 1);
            exports_2("handler", handler = function (event, context) {
                if (event != null) {
                    console.log('event = ' + JSON.stringify(event));
                }
                else {
                    console.log('No event object');
                }
                context.succeed('Hello World'); // SUCCESS with message
            });
        }
    }
});
System.register("Lambdas/main", ["Lambdas/gameVote"], function(exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var f;
    function handler(event, context) { console.log(JSON.stringify(f.handler)); f.handler(event, context); }
    exports_3("handler", handler);
    return {
        setters:[
            function (f_1) {
                f = f_1;
            }],
        execute: function() {
        }
    }
});
exports.handler = function (event, context) {console.log("gameVote");System.import("Lambdas/main").then(function (module) {console.log("3");module.handler(event, context);console.log("4");}).catch(ee=>{console.error(ee);});}